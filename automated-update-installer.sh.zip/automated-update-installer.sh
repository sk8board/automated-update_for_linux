#!/usr/bin/bash
#
# automated-update installer
#
# run script to install and enable automated-update.timer, .service., and application files


# Test for application package managers 
# apt-get (Debian/Ubuntu base) or 
# dnf (RedHat base) or 
# pacman (ArchLinux is a work in progress)

if [ -e "/usr/bin/apt-get" ]; then
appmgr_cmd="apt-get"
fi

if [ -e "/usr/bin/dnf" ]; then
appmgr_cmd="dnf"
fi

# ArchLinux is a work in progress
if [ -e "/usr/bin/pacman" ]; then
appmgr_cmd="pacman"
fi

echo "Test for application package managers completed"


# install dependencies if not already installed

if [ ! -e "/usr/bin/wget" ]; then
$appmgr_cmd install wget -y
fi

if [ ! -e "/usr/bin/ping" ]; then
$appmgr_cmd install iputils -y
fi

if [ ! -e "/usr/bin/notify-send" ]; then
$appmgr_cmd install libnotify -y
fi

if [ ! -e "/usr/bin/fwupdmgr" ]; then
$appmgr_cmd install fwupd -y
fi

echo "install dependencies completed"


# Download
wget https://raw.githubusercontent.com/sk8board/automated-update_for_linux/refs/heads/main/automated-update.timer

wget https://raw.githubusercontent.com/sk8board/automated-update_for_linux/refs/heads/main/automated-update.service

wget https://raw.githubusercontent.com/sk8board/automated-update_for_linux/refs/heads/main/automated-update

echo "Download completed"


# Move
mv automated-update.timer /usr/lib/systemd/system/

mv automated-update.service /usr/lib/systemd/system/

mv automated-update.py /usr/bin/

if [ -e "/usr/bin/semodule" ]; then
semanage fcontext -a -t systemd_unit_file_t -s system_u /usr/lib/systemd/system/automated-update.timer

semanage fcontext -a -t systemd_unit_file_t -s system_u /usr/lib/systemd/system/automated-update.service

semanage fcontext -a -t bin_t -s system_u /usr/bin/automated-update

echo "semanage completed"

restorecon -vF /usr/lib/systemd/system/automated-update.timer

restorecon -vF /usr/lib/systemd/system/automated-update.service

restorecon -vF /usr/bin/automated-update

echo "restorecon complete"
fi

echo "Move completed"


# Change owner to root
chown root /usr/lib/systemd/system/automated-update.timer

chown root /usr/lib/systemd/system/automated-update.service

chown root /usr/bin/automated-update

echo "Change owner to root completed"


# Change file permissions
chmod 644 /usr/lib/systemd/system/automated-update.timer

chmod 644 /usr/lib/systemd/system/automated-update.service

chmod 755 /usr/bin/automated-update

echo "Change file permissions completed"


# Enable, Start, Reload timer

systemctl status automated-update.timer
if [ $? -eq 0 ] ; then
systemctl stop automated-update.timer

systemctl disable automated-update.timer

systemctl daemon-reload

echo "timer needed to be disabled before enabling updated timer"
fi

systemctl enable automated-update.timer

systemctl start automated-update.timer

systemctl daemon-reload

echo "Enable, Start, Reload timer completed"


# notify of completion
echo "automated-update installation completed"


# notify_users() permits notify-send command to be used with sudo (root)
PATH=/usr/bin:/bin
notify_users()  
{
	XUSERS=($(who|grep -E '\(:[0-9](\.[0-9])*\)' |awk '{print $1$NF}'|sort -u))
	for XUSER in ${XUSERS[@]} ; do
	    NAME=(${XUSER/(/ })
	    DISPLAY=${NAME[1]/)/}
	    DBUS_ADDRESS=unix:path=/run/user/$(id -u ${NAME[0]})/bus
	    sudo -u ${NAME[0]} DISPLAY=${DISPLAY} \
	                       DBUS_SESSION_BUS_ADDRESS=${DBUS_ADDRESS} \
	                       PATH=${PATH} \
	                       notify-send "$@"
	done
}

notify_users "automated-update" "Installation Completed"

exit
