#!/usr/bin/bash
#
# automated-update installer
#
# run script to install and enable automated-update.timer, .service., and .py files


# start in the home directory
cd ~


# Test for application package managers 
# apt-get (Debian/Ubuntu base) or 
# dnf (RedHat base) or 
# pacman (ArchLinux is a work in progress)

apt-get --version
if [ $? -eq 0 ];then
app-cmd = /usr/bin/apt-get
fi

dnf --version
if [ $? -eq 0 ]; then
app-cmd = /user/bin/dnf
fi

# ArchLinux is a work in progress
pacman --version
if [ $? -eq 0 ]; then
app-cmd = /user/bin/pacman
fi


# install dependencies if not already installed

wget --version
if [ $? -ne 0 ]; then
$app-cmd install wget -y
fi

ping -V
if [ $? -ne 0 ]; then
$app-cmd install iputils -y
fi

notify-send --version
if [ $? -ne 0 ]; then
$app-cmd install libnotify -y
fi

fwupdmgr --version
if [ $? -ne 0 ]; then
$app-cmd install fwupd -y
fi


# Download
wget https://raw.githubusercontent.com/sk8board/automated-update_for_linux/refs/heads/main/automated-update.timer

wget https://raw.githubusercontent.com/sk8board/automated-update_for_linux/refs/heads/main/automated-update.service

wget https://raw.githubusercontent.com/sk8board/automated-update_for_linux/refs/heads/main/automated-update.py


# Make automated-update directory
mkdir /usr/lib/automated-update


# Move
mv automated-update.timer /usr/lib/systemd/system/

mv automated-update.service /usr/lib/systemd/system/

mv automated-update.py /usr/lib/automated-update/


# Change owner to root
chown root /usr/lib/systemd/system/automated-update.timer

chown root /usr/lib/systemd/system/automated-update.service

chown root /usr/lib/automated-update/automated-update.py


# Change file permissions
chmod 644 /usr/lib/systemd/system/automated-update.timer

chmod 644 /usr/lib/systemd/system/automated-update.service

chmod 755 /usr/lib/automated-update/automated-update.py


# Correct selinux inconsistent labels
restorecon -v
if [ $? -eq 0 ]; then
restorecon /usr/lib/systemd/system/automated-update.timer

restorecon /usr/lib/systemd/system/automated-update.service

restorecon /usr/lib/automated-update/automated-update.py
fi


# Enable, Start, Reload timer
systemctl enable automated-update.timer

systemctl start automated-update.timer

systemctl daemon-reload

notify-send "automated-update" "Installation Completed"

exit
